﻿#!/bin/bash
set -e

echo ">>> انتظار اتصال قاعدة البيانات SQL Server..."
until /opt/mssql-tools/bin/sqlcmd -S sqlserver -U sa -P $SA_PASSWORD -Q "SELECT 1" &> /dev/null; do
    echo ">>> SQL Server غير جاهز - انتظار..."
    sleep 2
done
echo ">>> تم تأكيد اتصال SQL Server"

echo ">>> جاري تنفيذ ترحيلات قاعدة البيانات..."
dotnet PrescriptoAI.dll --migrate
echo ">>> تم الانتهاء من ترحيلات قاعدة البيانات"

echo ">>> بدء تشغيل التطبيق..."
exec dotnet PrescriptoAI.dll