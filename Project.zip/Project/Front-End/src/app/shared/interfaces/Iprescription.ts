export interface IPrescription {
    id: number;
    imageUrl: string;
    analysisResult?: string;
    uploadedAt: string;
    pharmacistId: number;
  }