export interface Pharmacist {
    id: number;
    FullName: string;
    Email: string;
    createdAt: string;
    updatedAt: string;
  }