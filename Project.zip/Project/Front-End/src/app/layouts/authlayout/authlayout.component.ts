import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-authlayout',
  imports: [RouterOutlet],
  templateUrl: './authlayout.component.html',

})
export class AuthlayoutComponent {

}
